<?php
error_reporting(E_ERROR);
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

$db = Database::getInstance(); 
$conn = $db->getConnection();

// Check if cart is not empty
// if (empty($_SESSION['cart'])) {
//     header('Location: cart.php');
//     exit();
// }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'] ?? '';

    if ($payment_method === 'cod') {
        // Redirect to thank you page for Cash on Delivery
        header("Location: thankyou.php");
        exit();
    } elseif ($payment_method === 'paypal') {
        $error = "PayPal payment integration is under development.";
    } else {
        $error = "Please select a valid payment method.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <h2>Please Make Payment</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card mt-3">
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-check-label">
                            <input type="radio" name="payment_method" value="cod" class="form-check-input"> Cash On Delivery
                        </label>
                    </div>

                    <div class="mb-3">
                        <label class="form-check-label">
                            <input type="radio" name="payment_method" value="paypal" class="form-check-input"> PayPal
                        </label>
                    </div>

                    <button type="submit" class="btn btn-primary">Make Payment</button>
                </form>
            </div>
        </div>

        <div class="mt-3">
            <a href="cart.php" class="btn btn-secondary">Back to Cart</a>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
