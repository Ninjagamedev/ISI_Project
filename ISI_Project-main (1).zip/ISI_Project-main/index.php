<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$db = Database::getInstance(); 
$conn = $db->getConnection();

// Get featured products with images
$stmt = $conn->prepare("
    SELECT p.*, pi.image_path 
    FROM products p
    LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
    WHERE p.status = 'active'
    ORDER BY p.created_at DESC 
    LIMIT 8
");
$stmt->execute();
$featured_products = $stmt->fetchAll();

// Search functionality with images
$search_query = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$search_products = [];

if ($search_query) {
    $stmt = $conn->prepare("
        SELECT p.*, pi.image_path 
        FROM products p
        LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
        WHERE p.status = 'active' AND p.name LIKE ? 
        ORDER BY p.created_at DESC
    ");
    $stmt->execute(["%$search_query%"]);
    $search_products = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Shopping System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container">
        <div class="search-section">
            <form action="" method="GET">
                <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <?php if ($search_query): ?>
            <h2>Search Results for "<?php echo htmlspecialchars($search_query); ?>"</h2>
            <div class="product-grid">
                <?php if (empty($search_products)): ?>
                    <p>No products found.</p>
                <?php else: ?>
                    <?php foreach ($search_products as $product): ?>
                        <div class="product-card">
                            <img src="<?php echo !empty($product['image_path']) ? $product['image_path'] : 'assets/images/default.png'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="price">$<?php echo format_price($product['price']); ?></p>
                            <a href="product-details.php?id=<?php echo $product['id']; ?>" class="btn">View Details</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <h2>Featured Products</h2>
            <div class="product-grid">
                <?php foreach ($featured_products as $product): ?>
                    <div class="product-card">
                        <img src="<?php echo !empty($product['image_path']) ? $product['image_path'] : 'assets/images/default.png'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="price">$<?php echo format_price($product['price']); ?></p>
                        <a href="product-details.php?id=<?php echo $product['id']; ?>" class="btn">View Details</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
