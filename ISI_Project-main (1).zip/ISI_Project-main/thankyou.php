<?php
error_reporting(E_ERROR);
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';
// print_r($_SESSION);
$order_id = $_SESSION['order_id'] ?? null;

if (!$order_id) {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="alert alert-success">
            <h4>Thank you for placing your order!</h4>
            <p>Your order number is: <strong><?= htmlspecialchars($order_id) ?></strong></p>
        </div>

        <div class="d-flex gap-3">
            <a href="index.php" class="btn btn-primary">Continue Shopping</a>
            <a href="myaccount.php" class="btn btn-secondary">My Account</a>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
