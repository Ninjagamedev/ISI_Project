<?php
error_reporting(E_ERROR);
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['customer_id'])) {
    header('Location: login.php');
    exit();
}

$db = Database::getInstance();
$conn = $db->getConnection();

// Fetch user details
$stmt = $conn->prepare("SELECT name FROM customers WHERE id = :id");
$stmt->execute([':id' => $_SESSION['customer_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: logout.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <h2>Welcome, <?= htmlspecialchars($user['name']) ?>!</h2>
        <a href="logout.php" class="btn btn-danger">Logout</a>

        <ul class="nav nav-tabs mt-4" id="accountTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab">Edit Profile</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="orders-tab" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab">View Orders</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button" role="tab">Change Password</button>
            </li>
        </ul>
        <div class="tab-content mt-3" id="accountTabContent">
            <div class="tab-pane fade show active" id="profile" role="tabpanel">
                <p>Edit your profile information here.</p>
            </div>
            <div class="tab-pane fade" id="orders" role="tabpanel">
                <p>View your past orders here.</p>
            </div>
            <div class="tab-pane fade" id="password" role="tabpanel">
                <p>Change your password here.</p>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>