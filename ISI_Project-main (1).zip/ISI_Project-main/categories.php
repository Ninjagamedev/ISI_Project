<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$db = Database::getInstance(); 
$conn = $db->getConnection();

// Fetch categories
$stmt = $conn->prepare("SELECT * FROM categories WHERE parent_id IS NULL");
$stmt->execute();
$categories = $stmt->fetchAll();

// Fetch products by category
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';
$category = null;
$products = [];

if ($slug) {
    $categoryStmt = $conn->prepare("SELECT * FROM categories WHERE slug = :slug");
    $categoryStmt->bindParam(':slug', $slug);
    $categoryStmt->execute();
    $category = $categoryStmt->fetch();

    if ($category) {
        $productStmt = $conn->prepare("
            SELECT p.*, pi.image_path 
            FROM products p
            LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = 1
            WHERE p.category_id = :category_id AND p.status = 'active'
        ");
        $productStmt->bindParam(':category_id', $category['id']);
        $productStmt->execute();
        $products = $productStmt->fetchAll();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        .custom-list-group-item {
            color: gray;
            text-decoration: none;
        }
        .custom-list-group-item:hover {
            color: darkgray;
            text-decoration: underline;
        }

        .btn-primary {
    color: #fff;
    background-color: #333333;
    border-color: #0d6efd;
}
.page-item.active .page-link {
    z-index: 3;
    color: #fff;
    background-color:rgb(124, 124, 124);
    border-color: #0d6efd;
}
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <!-- Sidebar for Categories -->
            <div class="col-md-3">
                <h4>Categories</h4>
                <ul class="list-group">
                    <?php foreach ($categories as $cat): ?>
                        <li class="list-group-item">
                            <a href="categories.php?slug=<?php echo $cat['slug']; ?>" class="custom-list-group-item">
                                <i class="fas fa-arrow-right"></i> <?php echo htmlspecialchars($cat['name']); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Products List -->
            <div class="col-md-9">
                <?php if ($category): ?>
                    <h2><?php echo htmlspecialchars($category['name']); ?> Products</h2>
                    <div class="row">
                        <?php if (!empty($products)): ?>
                            <?php foreach ($products as $product): ?>
                                <div class="col-md-4 mb-4">
                                    <div class="card">
                                        <img src="<?php echo !empty($product['image_path']) ? $product['image_path'] : 'assets/images/default.png'; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                            <p class="card-text">$<?php echo format_price($product['price']); ?></p>
                                            <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-primary">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No products found in this category.</p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <p>Please select a category to view products.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
