<?php
error_reporting(E_ERROR);
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

$db = Database::getInstance(); 
$conn = $db->getConnection();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['user_email'])) {
            // Registration process
            $stmt = $conn->prepare("SELECT id FROM customers WHERE email = :email");
            $stmt->execute([':email' => $_POST['user_email']]);

            if ($stmt->rowCount() > 0) {
                $error = "You are an existing customer. Please login.";
            } else {
                if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
                    throw new Exception("Cart is empty. Please add products to the cart before proceeding.");
                }

                $conn->beginTransaction();

                $stmt = $conn->prepare("INSERT INTO customers (name, email, phone, password, billing_address, billing_city, billing_zip, shipping_address, shipping_city, shipping_zip) VALUES (:name, :email, :phone, :password, :billing_address, :billing_city, :billing_zip, :shipping_address, :shipping_city, :shipping_zip)");
                $stmt->execute([
                    ':name' => $_POST['user_name'],
                    ':email' => $_POST['user_email'],
                    ':phone' => $_POST['user_phone'],
                    ':password' => password_hash($_POST['user_password'], PASSWORD_DEFAULT),
                    ':billing_address' => $_POST['billing_address'],
                    ':billing_city' => $_POST['billing_city'],
                    ':billing_zip' => $_POST['billing_zip'],
                    ':shipping_address' => $_POST['shipping_address'],
                    ':shipping_city' => $_POST['shipping_city'],
                    ':shipping_zip' => $_POST['shipping_zip']
                ]);
                $customer_id = $conn->lastInsertId();
            }
        } elseif (isset($_POST['login_email'])) {
            // Login process
            $stmt = $conn->prepare("SELECT id, password FROM customers WHERE email = :email");
            $stmt->execute([':email' => $_POST['login_email']]);
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($customer && password_verify($_POST['login_password'], $customer['password'])) {
                $customer_id = $customer['id'];
            } else {
                throw new Exception("Invalid login credentials.");
            }
        }

        if (!isset($customer_id)) {
            throw new Exception("Customer processing error.");
        }

        $shipping_charge = 5.00;
        $subtotal = array_sum(array_map(function($item) {
            return $item['price'] * $item['quantity'];
        }, $_SESSION['cart']));
        $grand_total = $subtotal + $shipping_charge;

        $stmt = $conn->prepare("INSERT INTO main_order (customer_id, grand_total, order_date) VALUES (:customer_id, :grand_total, NOW())");
        $stmt->execute([
            ':customer_id' => $customer_id,
            ':grand_total' => $grand_total
        ]);
        $order_id = $conn->lastInsertId();

        foreach ($_SESSION['cart'] as $item) {
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, price, quantity) VALUES (:order_id, :product_id, :price, :quantity)");
            $stmt->execute([
                ':order_id' => $order_id,
                ':product_id' => $item['id'],
                ':price' => $item['price'],
                ':quantity' => $item['quantity']
            ]);
        }

        $_SESSION['customer_id'] = $customer_id;
        $_SESSION['user_email'] = $_POST['user_email'] ?? $_POST['login_email'];
        $_SESSION['order_id'] = $order_id;

        $conn->commit();
        unset($_SESSION['cart']);

        header('Location: payment.php');
        exit();
    } catch (Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .toggle-form { display: none; }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="container mt-4">
    <h2>Checkout</h2>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<div class="mb-3">
    <label>Are you an existing member?</label>
    <button class="btn btn-primary" onclick="toggleForm('login')">Login</button>
    <button class="btn btn-secondary" onclick="toggleForm('register')">Register</button>
</div>

<!-- Login Form -->
<div id="login-form" class="toggle-form">
    <form method="POST" action="">
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="login_email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="login_password" class="form-control" required>
        </div>
        <button type="submit" name="login" class="btn btn-primary">Login</button>
    </form>
</div>


<div id="register-form">
    <form method="POST" action="">
        <!-- User Information -->
        <div class="card mb-3">
            <div class="card-header">User Information</div>
            <div class="card-body">
                <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="user_name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="user_email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Phone</label>
                    <input type="text" name="user_phone" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" name="user_password" class="form-control" required>
                </div>
            </div>
        </div>

        <!-- Billing Details -->
        <div class="card mb-3">
            <div class="card-header">Billing Details</div>
            <div class="card-body">
                <div class="mb-3">
                    <label>Address</label>
                    <input type="text" name="billing_address" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>City</label>
                    <input type="text" name="billing_city" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>ZIP Code</label>
                    <input type="text" name="billing_zip" class="form-control" required>
                </div>
            </div>
        </div>

        <!-- Shipping Details -->
        <div class="card mb-3">
            <div class="card-header">Shipping Details</div>
            <div class="card-body">
                <div class="mb-3">
                    <label>Address</label>
                    <input type="text" name="shipping_address" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>City</label>
                    <input type="text" name="shipping_city" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>ZIP Code</label>
                    <input type="text" name="shipping_zip" class="form-control" required>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Place Order</button>
    </form>
</div>

</div>

<?php include 'includes/footer.php'; ?>
<script>
    function toggleForm(type) {
        document.getElementById('login-form').style.display = type === 'login' ? 'block' : 'none';
        document.getElementById('register-form').style.display = type === 'register' ? 'block' : 'none';
    }
    toggleForm('register');
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>