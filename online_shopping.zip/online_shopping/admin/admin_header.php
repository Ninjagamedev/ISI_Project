<header class="admin-header">
    <nav class="admin-nav">
        <div class="logo">
            <a href="<?php echo BASE_URL; ?>admin/">Admin Panel</a>
        </div>
        <ul class="nav-links">
            <li><a href="<?php echo BASE_URL; ?>admin/">Dashboard</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/products.php">Products</a></li>
            <li><a href="<?php echo BASE_URL; ?>admin/orders.php">Orders</a></li>
            <li><a href="<?php echo BASE_URL; ?>">View Store</a></li>
        </ul>
    </nav>
</header>
